package LibreriaMatematica;

public class TestPrimosEntreSi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Método que calcula si dos números son primos entre sí: ");
        System.out.println(LibreriaMatematica.esPrimoEntreSi(5, 18));

        System.out.print("\nMétodo que calcula si dos números son primos entre sí: ");
        System.out.println(LibreriaMatematica.esPrimoEntreSi(20, 9));

        System.out.print("\nMétodo que calcula si dos números son primos entre sí: ");
        System.out.println(LibreriaMatematica.esPrimoEntreSi(7, 10));

        System.out.print("\nMétodo que calcula si dos números son primos entre sí: ");
        System.out.println(LibreriaMatematica.esPrimoEntreSi(6, 0));

        System.out.print("\nMétodo que calcula si dos números son primos entre sí: ");
        System.out.println(LibreriaMatematica.esPrimoEntreSi(-6, -2));
	}

}
