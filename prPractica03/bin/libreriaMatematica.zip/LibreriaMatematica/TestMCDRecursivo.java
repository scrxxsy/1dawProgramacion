package LibreriaMatematica;

public class TestMCDRecursivo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Método que calcula el MCD de forma recursiva de dos números: ");
        System.out.println(LibreriaMatematica.maxComDivRecu(270, 192));
        
        System.out.print("\nMétodo que calcula el MCD de forma recursiva de dos números: ");
        System.out.println(LibreriaMatematica.maxComDivRecu(5, 10));
        
        System.out.print("\nMétodo que calcula el MCD de forma recursiva de dos números: ");
        System.out.println(LibreriaMatematica.maxComDivRecu(27, 2));
        
        System.out.print("\nMétodo que calcula el MCD de forma recursiva de dos números: ");
        System.out.println(LibreriaMatematica.maxComDivRecu(23, 12));
	}

}
