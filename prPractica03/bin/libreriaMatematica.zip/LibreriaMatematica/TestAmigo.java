package LibreriaMatematica;

public class TestAmigo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Método que calcula si dos números son amigos: ");
        System.out.println(LibreriaMatematica.esAmigo(6, 6));

        System.out.print("\nMétodo que calcula si dos números son amigos: ");
        System.out.println(LibreriaMatematica.esAmigo(28, 28));

        System.out.print("\nMétodo que calcula si dos números son amigos: ");
        System.out.println(LibreriaMatematica.esAmigo(220, 284));

        System.out.print("\nMétodo que calcula si dos números son amigos: ");
        System.out.println(LibreriaMatematica.esAmigo(9, 15));
	}

}
