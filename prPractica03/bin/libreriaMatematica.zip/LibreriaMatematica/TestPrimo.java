package LibreriaMatematica;

public class TestPrimo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Método que devuelve si un número es primo o no: ");
		System.out.println(LibreriaMatematica.esPrimo(2));
		System.out.println(LibreriaMatematica.esPrimo(-1));
		System.out.println(LibreriaMatematica.esPrimo(7));
		System.out.println(LibreriaMatematica.esPrimo(21));
	}

}
