package LibreriaMatematica;

public class TestPerfecto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Método que devuelve si un número es perfecto o no: ");
		System.out.println(LibreriaMatematica.esPerfecto(6) ? "Es perfecto" : " No es perfecto");
		System.out.println(LibreriaMatematica.esPerfecto(28)? "Es perfecto" : " No es perfecto");
		System.out.println(LibreriaMatematica.esPerfecto(496)? "Es perfecto" : " No es perfecto");
		System.out.println(LibreriaMatematica.esPerfecto(3)? "Es perfecto" : "No es perfecto");

	}

}
