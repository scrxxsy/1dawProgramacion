package LibreriaMatematica;

public class TestSumaFibo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int cont=0;cont<=10;cont++) {
            System.out.println("Suma Fib("+cont+"): " + LibreriaMatematica.calcSumaFibo(cont));
        }

	}

}
