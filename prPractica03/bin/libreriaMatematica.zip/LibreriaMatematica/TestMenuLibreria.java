package LibreriaMatematica;

import java.util.Scanner;



public class TestMenuLibreria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte op;
		Scanner sc = new Scanner (System.in);
			do {
				menu();
				System.out.println("\t\tElija una opción (1..8): ");
				op=sc.nextByte();
					switch (op) {
					case 1 -> proceso1(sc);
					case 2 -> proceso2(sc);
					case 3 -> proceso3(sc);
					case 4 -> proceso3(sc);
					case 5 -> proceso3(sc);
					case 6 -> proceso3(sc);
					case 7 -> proceso3(sc);
					case 8 -> System.out.println("Fin de Programa");
					
					default -> System.out.println("Opción incorrecta");
					
					}
					

			}
			while (op!=8);

		sc.close();
	}
	
	public static void menu() {
		System.out.println("==OPCIONES LIBRERIA MATEMÁTICA==" + 
							"\n1.Calcular el factorial de un número." + 
							"\n2.Mostrar el combinatorio de dos números dados." +
							"\n3.Visualizar los números primos entre dos números dados." +
							"\n4.Visualizar por pantalla los números perfector que hay entre 2 números dados." +
							"\n5.Visualizar por pantalla las parejas de números amigos que hay entre 2 números dados." +
							"\n6.Comprobar si dos números son primos entre sí" +
							"\n7.Calcular la función de Euler de un número" +
							"\n8.Salir"
							);
	}
	
	public static void proceso1 (Scanner sc) {
		int num;
		long factorial;
		System.out.println("Introduzca el número al que realizar el factorial: ");
		num=sc.nextInt();
		factorial = LibreriaMatematica.calcularFactorial(num);
		
		if(factorial==-1) {
			System.out.println("No se puede hacer el factorial de un número negativo");
		}
		
		else {
		System.out.println("El factorial de " + num + " es " + factorial);
		}
	}
	public static void proceso2 (Scanner sc) {
		int num1, num2;
		double combinatorio;
		
		System.out.println("Introduzca el valor del primer número: ");
		num1=sc.nextInt();
		
		System.out.println("Introduzca el valor del segundo número: ");
		num2=sc.nextInt();
		
		combinatorio = LibreriaMatematica.calcularCombinatorio(num1, num2);
		
		if(combinatorio == -1) {
			System.out.println("No se puede calcular el combinatorio de números negativos");
			
		}
		else {
			System.out.println("El combinatorio de " + num1 + " sobre " + num2 + " es " + combinatorio) ;
		}
		
		
		
		
	}
	
	public static void proceso3 (Scanner sc) {
		int num1, num2;
		
		System.out.println("Introduzca el valor del primer número: ");
		num1=sc.nextInt();
		
		System.out.println("Introduzca el valor del primer número: ");
		num2=sc.nextInt();
		
		for (int cont = num1; cont<=num2; cont++) {
			if(LibreriaMatematica.esPrimo(cont)) {
				System.out.println(cont);
			}
		}


		
			

	}
	
	public static void proceso4 (Scanner sc) {
		int num1, num2;
		
		System.out.println("Introduzca el valor del primer número: ");
		num1=sc.nextInt();
		
		System.out.println("Introduzca el valor del primer número: ");
		num2=sc.nextInt();
		
		
	}
	
	

}


