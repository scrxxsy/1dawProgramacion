package LibreriaMatematica;

public class TestEuler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Método que calcula la función de Euler: ");
        System.out.println(LibreriaMatematica.calcEuler(20));
        
        System.out.print("\nMétodo que calcula la función de Euler: ");
        System.out.println(LibreriaMatematica.calcEuler(4));
        
        System.out.print("\nMétodo que calcula la función de Euler: ");
        System.out.println(LibreriaMatematica.calcEuler(8));
        
        System.out.print("\nMétodo que calcula la función de Euler: ");
        System.out.println(LibreriaMatematica.calcEuler(19));
        
        System.out.print("\nMétodo que calcula la función de Euler: ");
        System.out.println(LibreriaMatematica.calcEuler(-19));
	}

}
